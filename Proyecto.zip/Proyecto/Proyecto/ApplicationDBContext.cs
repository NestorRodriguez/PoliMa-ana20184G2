﻿namespace Proyecto
{
    internal class ApplicationDBContext
    {
    }
}